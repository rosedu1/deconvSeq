# deconvseq
deconvolution for RNAseq and bisulfite sequencing
